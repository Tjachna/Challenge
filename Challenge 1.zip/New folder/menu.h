#include <iostream>
#include <stdlib.h>

void mainMenu();
void printMenu();
void printMenuWeight();
void printMenuLength();
void printMenuLengthInches();