#include "length.h"

void printInchesToCm(){
	float inputLength;
	std::cout << "Inches: ";
	std::cin >> inputLength;
	std::cout << std::endl;
	std::cout << "Cm: " + std::to_string(inputLength * 2.54);
};

void printInchesToFeet(){
	float inputLength;
	std::cout << "Inches: ";
	std::cin >> inputLength;
	std::cout << std::endl;
	std::cout << "Feet: " + std::to_string(inputLength * 0.08);
};

void printInchesToMeters(){
	float inputLength;
	std::cout << "Inches: ";
	std::cin >> inputLength;
	std::cout << std::endl;
	std::cout << "Meters: " + std::to_string(inputLength * 0.0254);
};

void printInchesToYards(){
	float inputLength;
	std::cout << "Inches: ";
	std::cin >> inputLength;
	std::cout << std::endl;
	std::cout << "Yards: " + std::to_string(inputLength * 0.027);
};