#include <iostream>
#include <stdlib.h>

void printInchesToCm();
void printInchesToFeet();
void printInchesToMeters();
void printInchesToYards();