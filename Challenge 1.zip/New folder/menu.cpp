#include "menu.h"
#include "length.h"
#include "weight.h"

void printMenu(){
	std::cout << "What units are we gonna convert?" << std::endl;
	std::cout << "1. Weight" << std::endl;
	std::cout << "2. Length" << std::endl;
	std::cout << "3. Time" << std::endl;
	std::cout << "0. Exit" << std::endl;
};

void printMenuWeight(){
	std::cout << "1. Pounds to kilograms" << std::endl;
	std::cout << "2. Kilograms to pounds" << std::endl;
    std::cout << "0. Exit" << std::endl;
};

void printMenuLength(){
	std::cout << "1. Inches" << std::endl;
	std::cout << "2. Feet" << std::endl;
	std::cout << "3. Yards" << std::endl;
	std::cout << "4. Cm" << std::endl;
	std::cout << "5. Meters" << std::endl;
    std::cout << "0. Exit" << std::endl;
};

void printMenuLengthInches(){
	std::cout << "1. Inches to cm" << std::endl;
	std::cout << "2. Inches to feet" << std::endl;
	std::cout << "3. Inches to meters" << std::endl;
	std::cout << "4. Inches to yards" << std::endl;
    std::cout << "0. Exit" << std::endl;
};

void mainMenu(){
    int choice;
	int choice2;
	int choice3;
    printMenu();
	std::cin >> choice;
	while (choice != 0){
	switch(choice){
		case 1:
		system("cls");
		printMenuWeight();
		std::cin >> choice2;
			
			switch(choice2) {
				while (choice2 != 0) {
				case 1:
				system("cls");
				std::cout << "Pounds to kilograms:" << std::endl;
				printPoundsToKg();
				std::cin >> choice2;
				break;

				case 2:
				system("cls");
				std::cout << "Kilograms to pounds:" << std::endl;
				printKgToPound();
				std::cin >> choice2;
				break;

				case 0:
				mainMenu();
				}
			
		system("pause");
			}
		break;
		case 2:
		system("cls");
		printMenuLength();
		std::cin >> choice2;
			while (choice2 != 0){
				switch(choice2) {
					case 1:
					system("cls");
					printMenuLengthInches();
					std::cin >> choice3;
					while (choice3 != 0){
						switch(choice3){
							case 1:
							system("cls");
							std::cout << "Inches to cm: " << std::endl;
							printInchesToCm();
							system("break");
							break;
						}
					}
				}
			}
		default:
		break;
		}
	}
}