#include <iostream>
#include <stdlib.h>

void printPoundsToKg();
void printKgToPound();