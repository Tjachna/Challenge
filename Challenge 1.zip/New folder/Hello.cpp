
#include <iostream>
#include <stdlib.h>

#include "menu.cpp"
#include "weight.cpp"
#include "length.cpp"

int main()
{	
	mainMenu();
	

	return 0;
}

