#include "weight.h"

void printPoundsToKg(){
	float inputWeight;
	std::cout << "Pounds: ";
	std::cin >> inputWeight;
	std::cout << std::endl;
	std::cout << "Kilograms: " + std::to_string(inputWeight * 0.45);
	std::cout << std::endl;
};

void printKgToPound(){
	float inputWeight;
	std::cout << "Kilograms: ";
	std::cin >> inputWeight;
	std::cout << std::endl;
	std::cout << "Pounds: " + std::to_string(inputWeight * 2.2);
	std::cout << std::endl;
};