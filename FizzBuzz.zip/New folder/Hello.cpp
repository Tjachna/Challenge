
#include <iostream>

int main()
{	
	for (int i = 1; i < 101; i++) {
		if(i%15 == 0)
			std::cout << i << ": is FizzBuzz" << std::endl;
		else if (i%5 == 0)
			std::cout << i << ": is Buzz" << std::endl;
		else if (i%3 == 0)
			std::cout << i << ": is Fizz" << std::endl;
		else
			std::cout << i << std::endl;
	};
}
