#include <iostream>
#include <vector>

int binarySearch(std::vector<int>, int);

int main()
{	
auto toFind = 8;
std::vector<int> vec {1,2,3,4,5,6,7,8,9};
auto first = 0;
auto last = vec.size()-1;

while (first <= last) {
	auto guess = (first+last)/2;
	if (toFind == vec[guess]) {
		std::cout << "found at " << guess;
		break;
	} else if (vec[guess] > toFind) {
		last = guess - 1;
	} else {
		first = guess + 1;
	}
};
}