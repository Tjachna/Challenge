#include <iostream>
#include <vector>
#include <bitset>
#include <string>
#include <map>

void ipToBin(std::string &);

std::vector<int> splitIp(std::string);
std::vector<int> computeNetwork(std::vector<int>, std::vector<int>);
std::vector<int> computeBroadcast(std::vector<int>, std::vector<int>);
std::string concatIp(std::vector<int>);


int main()
{	
	std::vector<int> myIp = splitIp("111.222.123.221");
	std::vector<int> myMask = splitIp("255.255.255.252");
	std::vector<int> myNetwork;
	std::vector<int> myBroadcast;
	

	myNetwork = computeNetwork (myIp, myMask);
	myBroadcast = computeBroadcast(myNetwork, myMask);

	std::vector<int> myFirstHost = myNetwork;
	std::vector<int> myLastHost = myBroadcast;
	myFirstHost[3] = myFirstHost[3]+1;
	myLastHost[3] = myLastHost[3]-1;

	std::cout << "For IP address: " << concatIp(myIp) << " and mask: " << concatIp(myMask) << std::endl;

	std::cout << "Your Network address is: " << concatIp(myNetwork) << std::endl;
	std::cout << "Your Broadcast address is: " << concatIp(myBroadcast) << std::endl;
	std::cout << "Your First host address is: " << concatIp(myFirstHost) << std::endl;
	std::cout << "Your Last host address is: " << concatIp(myLastHost) << std::endl;

};


std::vector<int> splitIp(std::string ip) {
	std::vector<int> chunkedIp;
	chunkedIp.push_back(std::stoi(ip.substr(0,3)));
	chunkedIp.push_back(std::stoi(ip.substr(4,3)));
	chunkedIp.push_back(std::stoi(ip.substr(8,3)));
	chunkedIp.push_back(std::stoi(ip.substr(12,3)));
	return chunkedIp;
}

std::vector<int> computeNetwork(std::vector<int> inputIp, std::vector<int> inputMask) {
	std::vector<int> outputNetwork;
		for (int i = 0; i < inputIp.size(); i++) {
		if (inputMask[i] == 0)
			outputNetwork.push_back(0);
		else if (inputMask[i] == 255)
			outputNetwork.push_back(inputIp[i]);
		else {
			outputNetwork.push_back(inputIp[i]&inputMask[i]);
		}
	}
	return outputNetwork;
}


std::vector<int> computeBroadcast(std::vector<int> inputNetwork, std::vector<int> inputMask) {
	std::vector<int> outputBroadcast;
		for (int i = 0; i < inputNetwork.size(); i++) {
			inputMask[i] = (inputMask[i]^255);
			outputBroadcast.push_back(inputNetwork[i]|inputMask[i]);
		}
	return outputBroadcast;
}

std::string concatIp(std::vector<int> ipVector){
	std::string resultIp = std::to_string(ipVector[0]) + "." + std::to_string(ipVector[1]) + "." + std::to_string(ipVector[2]) + "." + std::to_string(ipVector[3]);
	return resultIp;
}