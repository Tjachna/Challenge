
#include <iostream>
#include <fstream>

int readFile(std::string, std::string);

int main()
{	
	std::cout << readFile("inputdoc.txt", "words");
	return 0;
}

int readFile(std::string fileName, std::string lookFor){
	int counter = 0;
	std::fstream file;
	file.open(fileName);
	if (!file.is_open()){
		std::cout << "Couldn't open the file";
		return 0;
	}
	std::string word;
	while (file >> word) {
		if (word == lookFor) {
			counter++;
		}
	}
	file.close();

	return counter;
}